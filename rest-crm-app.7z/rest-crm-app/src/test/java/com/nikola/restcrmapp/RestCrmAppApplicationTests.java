package com.nikola.restcrmapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestCrmAppApplicationTests {

    @Test
    void contextLoads() {
    }

}
