package com.nikola.restcrmappclient.service;

import com.nikola.restcrmappclient.entity.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@Service
public class EmployeeService implements IEmployeeService{
    private final String employeeApiBaseUrl;
    private final RestTemplate restTemplate;
    @Autowired
    public EmployeeService(@Value("${employee.api.base.url}") String employeeApiBaseUrl, RestTemplate restTemplate) {
        this.employeeApiBaseUrl = employeeApiBaseUrl;
        this.restTemplate = restTemplate;
    }
    @Override
    public List<Employee> getAllEmployees() {
        return restTemplate.exchange(employeeApiBaseUrl, HttpMethod.GET, null, new ParameterizedTypeReference<List<Employee>>() {}
        ).getBody();
    }

    @Override
    public Employee getEmployeeById(Long id) {
        return restTemplate.getForObject(employeeApiBaseUrl + "/" + id, Employee.class
        );
    }

    @Override
    public Employee createEmployee(Employee employee) {
        return restTemplate.postForObject(employeeApiBaseUrl, employee, Employee.class
        );
    }

    @Override
    public Employee updateEmployee(Long id, Employee employee) {
        HttpEntity<Employee> request = new HttpEntity<>(employee);
        return restTemplate.exchange(employeeApiBaseUrl + "/" + id, HttpMethod.PUT, request, Employee.class
        ).getBody();
    }

    @Override
    public void deleteEmployee(Long id) {
        restTemplate.delete(employeeApiBaseUrl + "/" + id);
    }
}
