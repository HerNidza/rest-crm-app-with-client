package com.nikola.restcrmappclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestCrmAppClientApplicationTests {

    @Test
    void contextLoads() {
    }

}
